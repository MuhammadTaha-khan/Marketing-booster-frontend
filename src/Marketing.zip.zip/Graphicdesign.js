import React from 'react'
import './component/graphicdes.css'

function Graphicdesign() {
  return (
    <div>
      <h2 className='text-center mt-5'>
        IT IS CREATING
      </h2>
    </div>
  )
}

export default Graphicdesign

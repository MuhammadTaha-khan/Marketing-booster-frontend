import React from 'react'

function Contwriting() {
  return (
    <div>
      {/* <h1 className='text-center mt-5'>CONSTRACTION</h1> */}
    </div>
  )
}

export default Contwriting